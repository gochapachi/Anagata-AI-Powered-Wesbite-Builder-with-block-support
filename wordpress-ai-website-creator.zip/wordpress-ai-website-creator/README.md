# WordPress AI Website Creator

This plugin uses AI to create a complete WordPress website based on user input.

## Features

- AI-powered chatbot to gather business information
- Automatic page creation with WordPress blocks
- AI-generated images using DALL-E 3
- WooCommerce integration for e-commerce sites
- Elementor compatibility
- Subtle animations for enhanced user experience

## Installation

1. Upload the `wordpress-ai-website-creator` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to the 'AI Website Creator' menu in the WordPress admin area
4. Enter your OpenAI API key in the settings
5. Start the chatbot to create your AI-powered website

## Requirements

- WordPress 5.0 or higher
- PHP 7.2 or higher
- OpenAI API key

## Support

For support, please create an issue in the GitHub repository or contact the plugin author.

## License

This plugin is licensed under the GPL v2 or later.