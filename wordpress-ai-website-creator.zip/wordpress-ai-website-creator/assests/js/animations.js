document.addEventListener('DOMContentLoaded', (event) => {
    const animatedElements = document.querySelectorAll('.wp-block-group');

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
            } else {
                entry.target.classList.remove('fade-in');
            }
        });
    });

    animatedElements.forEach(el => observer.observe(el));
});