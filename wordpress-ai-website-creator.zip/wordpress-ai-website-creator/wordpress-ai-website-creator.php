<?php
/**
 * Plugin Name: WordPress AI Website Creator
 * Description: Creates a WordPress website with AI-powered content and design.
 * Version: 1.0
 * Author: Your Name
 */

if (!defined('ABSPATH')) {
    exit;
}

define('WAWC_VERSION', '1.0');
define('WAWC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WAWC_PLUGIN_URL', plugin_dir_url(__FILE__));

require_once WAWC_PLUGIN_DIR . 'includes/class-openai-integration.php';
require_once WAWC_PLUGIN_DIR . 'includes/class-chatbot.php';
require_once WAWC_PLUGIN_DIR . 'includes/class-image-generator.php';
require_once WAWC_PLUGIN_DIR . 'includes/class-page-generator.php';
require_once WAWC_PLUGIN_DIR . 'includes/class-woocommerce-integration.php';
require_once WAWC_PLUGIN_DIR . 'includes/class-elementor-compatibility.php';
require_once WAWC_PLUGIN_DIR . 'admin/class-admin-menu.php';

function wawc_init() {
    if (!current_user_can('manage_options')) {
        return;
    }

    new WAWC_Chatbot();
    new WAWC_Page_Generator();
    new WAWC_WooCommerce_Integration();
    new WAWC_Elementor_Compatibility();
}
add_action('plugins_loaded', 'wawc_init');

function wawc_enqueue_scripts() {
    wp_enqueue_script('wawc-animations', WAWC_PLUGIN_URL . 'assets/js/animations.js', array(), WAWC_VERSION, true);
    wp_enqueue_style('wawc-animations', WAWC_PLUGIN_URL . 'assets/css/animations.css', array(), WAWC_VERSION);
}
add_action('wp_enqueue_scripts', 'wawc_enqueue_scripts');