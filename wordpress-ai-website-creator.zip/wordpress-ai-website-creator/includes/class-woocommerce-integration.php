<?php
class WAWC_WooCommerce_Integration {
    public function setup_shop($business_info) {
        if (!class_exists('WooCommerce')) {
            return;
        }

        foreach ($business_info['product_categories'] as $category) {
            wp_insert_term($category['name'], 'product_cat', [
                'description' => $category['description'],
            ]);
        }

        foreach ($business_info['sample_products'] as $product) {
            $this->create_product($product);
        }
    }

    private function create_product($product_data) {
        $product = new WC_Product_Simple();
        $product->set_name($product_data['name']);
        $product->set_regular_price($product_data['price']);
        $product->set_description($product_data['description']);
        $product->set_category_ids([$product_data['category_id']]);

        $image_generator = new WAWC_Image_Generator();
        $product_image = $image_generator->generate_image($product_data['name'] . " product image");
        if (!isset($product_image['error'])) {
            $product->set_image_id($product_image['attachment_id']);
        }

        $product->save();
    }
}