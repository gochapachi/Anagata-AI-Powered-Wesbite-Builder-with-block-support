<?php
class WAWC_OpenAI_Integration {
    private $api_key;
    private $api_url = 'https://api.openai.com/v1/chat/completions';

    public function __construct() {
        $this->api_key = get_option('wawc_openai_api_key');
    }

    public function generate_response($messages, $functions = null) {
        $headers = [
            'Authorization' => 'Bearer ' . $this->api_key,
            'Content-Type' => 'application/json',
        ];

        $body = [
            'model' => 'gpt-4-mini',
            'messages' => $messages,
        ];

        if ($functions) {
            $body['functions'] = $functions;
        }

        $response = wp_remote_post($this->api_url, [
            'headers' => $headers,
            'body' => json_encode($body),
        ]);

        if (is_wp_error($response)) {
            return ['error' => $response->get_error_message()];
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        return $body['choices'][0]['message'];
    }
}