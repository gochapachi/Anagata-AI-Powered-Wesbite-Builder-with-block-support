<?php
class WAWC_Image_Generator {
    private $api_key;
    private $api_url = 'https://api.openai.com/v1/images/generations';

    public function __construct() {
        $this->api_key = get_option('wawc_openai_api_key');
    }

    public function generate_image($prompt, $size = '1024x1024', $n = 1) {
        $headers = [
            'Authorization' => 'Bearer ' . $this->api_key,
            'Content-Type' => 'application/json',
        ];

        $body = [
            'model' => 'dall-e-3',
            'prompt' => $prompt,
            'size' => $size,
            'n' => $n,
            'response_format' => 'url',
        ];

        $response = wp_remote_post($this->api_url, [
            'headers' => $headers,
            'body' => json_encode($body),
        ]);

        if (is_wp_error($response)) {
            return ['error' => $response->get_error_message()];
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['data'][0]['url'])) {
            return $this->save_image($body['data'][0]['url']);
        } else {
            return ['error' => 'Failed to generate image'];
        }
    }

    private function save_image($url) {
        $upload_dir = wp_upload_dir();
        $image_data = file_get_contents($url);
        
        if ($image_data === false) {
            return ['error' => 'Failed to download image'];
        }

        $filename = 'dalle-' . uniqid() . '.png';
        $file_path = $upload_dir['path'] . '/' . $filename;
        
        if (file_put_contents($file_path, $image_data) === false) {
            return ['error' => 'Failed to save image'];
        }

        $attachment = [
            'post_mime_type' => 'image/png',
            'post_title' => sanitize_file_name($filename),
            'post_content' => '',
            'post_status' => 'inherit'
        ];

        $attach_id = wp_insert_attachment($attachment, $file_path);

        if (is_wp_error($attach_id)) {
            return ['error' => $attach_id->get_error_message()];
        }

        require_once(ABSPATH . 'wp-admin/includes/image.php');
        $attach_data = wp_generate_attachment_metadata($attach_id, $file_path);
        wp_update_attachment_metadata($attach_id, $attach_data);

        return [
            'success' => true,
            'attachment_id' => $attach_id,
            'url' => wp_get_attachment_url($attach_id)
        ];
    }
}