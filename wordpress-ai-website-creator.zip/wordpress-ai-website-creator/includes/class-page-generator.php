<?php
class WAWC_Page_Generator {
    private $image_generator;

    public function __construct() {
        $this->image_generator = new WAWC_Image_Generator();
    }

    public function generate_pages() {
        $business_info = get_option('wawc_business_info');

        $this->create_home_page($business_info);
        $this->create_about_page($business_info);
        $this->create_services_page($business_info);
        $this->create_contact_page($business_info);
    }

    private function create_home_page($business_info) {
        $content = '<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">
    <!-- wp:heading {"level":1} -->
    <h1>' . esc_html($business_info['business_name']) . '</h1>
    <!-- /wp:heading -->

    <!-- wp:paragraph -->
    <p>' . esc_html($business_info['business_type']) . '</p>
    <!-- /wp:paragraph -->

    <!-- wp:image {"id":HERO_IMAGE_ID,"sizeSlug":"large","linkDestination":"none"} -->
    <figure class="wp-block-image size-large"><img src="HERO_IMAGE_URL" alt="' . esc_attr($business_info['business_name']) . ' hero image" class="wp-image-HERO_IMAGE_ID"/></figure>
    <!-- /wp:image -->
</div>
<!-- /wp:group -->';

        $hero_image = $this->image_generator->generate_image($business_info['business_name'] . " business hero image");
        if (!isset($hero_image['error'])) {
            $content = str_replace('HERO_IMAGE_ID', $hero_image['attachment_id'], $content);
            $content = str_replace('HERO_IMAGE_URL', $hero_image['url'], $content);
        }

        $page_id = wp_insert_post([
            'post_title'    => 'Home',
            'post_content'  => $content,
            'post_status'   => 'publish',
            'post_type'     => 'page',
        ]);

        if ($page_id) {
            update_option('page_on_front', $page_id);
            update_option('show_on_front', 'page');
        }
    }

    // Add methods for creating other pages (about, services, contact) here
}