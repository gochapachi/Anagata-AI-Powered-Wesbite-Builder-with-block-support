<?php
class WAWC_Chatbot {
    private $openai;
    private $conversation_history = [];

    public function __construct() {
        add_action('wp_ajax_wawc_chatbot_request', array($this, 'handle_chatbot_request'));
        $this->openai = new WAWC_OpenAI_Integration();
    }

    public function handle_chatbot_request() {
        check_ajax_referer('wawc_chatbot_nonce', 'nonce');

        $user_input = sanitize_text_field($_POST['user_input']);
        $this->conversation_history[] = ['role' => 'user', 'content' => $user_input];

        $functions = $this->get_functions();
        $response = $this->openai->generate_response($this->conversation_history, $functions);

        if (isset($response['function_call'])) {
            $function_name = $response['function_call']['name'];
            $arguments = json_decode($response['function_call']['arguments'], true);
            $function_response = $this->call_function($function_name, $arguments);
            $this->conversation_history[] = [
                'role' => 'function',
                'name' => $function_name,
                'content' => json_encode($function_response),
            ];
            $response = $this->openai->generate_response($this->conversation_history);
        }

        $this->conversation_history[] = $response;
        wp_send_json_success($response);
    }

    private function get_functions() {
        return [
            [
                'name' => 'save_business_info',
                'description' => 'Save the collected business information',
                'parameters' => [
                    'type' => 'object',
                    'properties' => [
                        'business_name' => ['type' => 'string'],
                        'business_type' => ['type' => 'string'],
                        'services' => ['type' => 'array', 'items' => ['type' => 'string']],
                        'contact_email' => ['type' => 'string'],
                        'phone_number' => ['type' => 'string'],
                    ],
                    'required' => ['business_name', 'business_type', 'contact_email'],
                ],
            ],
        ];
    }

    private function call_function($function_name, $arguments) {
        switch ($function_name) {
            case 'save_business_info':
                return $this->save_business_info($arguments);
            default:
                return ['error' => 'Unknown function'];
        }
    }

    private function save_business_info($info) {
        update_option('wawc_business_info', $info);
        return ['success' => true, 'message' => 'Business information saved successfully'];
    }
}