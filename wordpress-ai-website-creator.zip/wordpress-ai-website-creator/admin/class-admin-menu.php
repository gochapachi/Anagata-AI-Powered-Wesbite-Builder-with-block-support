<?php
class WAWC_Admin_Menu {
    public function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
    }

    public function add_admin_menu() {
        add_menu_page(
            'AI Website Creator',
            'AI Website Creator',
            'manage_options',
            'wawc-settings',
            [$this, 'display_settings_page'],
            'dashicons-admin-generic',
            100
        );
    }

    public function display_settings_page() {
        // Display the settings page HTML here
        echo '<div class="wrap">';
        echo '<h1>AI Website Creator Settings</h1>';
        // Add form for OpenAI API key and other settings
        echo '</div>';
    }
}